import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PacUserService } from '../pac-user.service';
import { Slots } from '../slots';
import { Vcenters } from '../vcenters';

@Component({
  selector: 'app-user-homepage',
  templateUrl: './user-homepage.component.html',
  styleUrls: ['./user-homepage.component.css']
})
export class UserHomepageComponent implements OnInit {
  userTable:boolean = false;
  vCenters:boolean = false
  bookSlot:boolean = false
  helpInfo:boolean = false
  showVCenter:boolean = false
  pinCode:number=0
  slotDate: Date | undefined
  slotTime: string=''
  vType: string=''
  vCentersData:any = []
  vcenters:Vcenters= new Vcenters();
  slots:Slots= new Slots();
  message : any;
  constructor(private router: Router,public service: PacUserService) { }

  ngOnInit() {
    
  }

  onBtnClick(value:string){
    if(value == "showVCenter"){
      this.userTable = false
      this.showVCenter = true
      this.bookSlot = false
    }
    else if(value == "userTable"){
      this.userTable = true
      this.showVCenter = false
      this.bookSlot = false
    }
    else{
      this.slots.centerName= value
      this.userTable = false
      this.showVCenter = false
      this.bookSlot = true
    }
    
  }
  
   public findVcentersByPinCode(){
   let response = this.service.getVcentersByPinCode(this.vcenters.pinCode);
   response.subscribe(data => this.vCentersData = data);
  }

  public confirmSlot(){
    console.log(this.slots)
    this.slots.userName= this.service.getUserName();
    
    let reponse = this.service.doSlotBook(this.slots);
      reponse.subscribe(data => {
        this.message = data;
      });

  }

}
