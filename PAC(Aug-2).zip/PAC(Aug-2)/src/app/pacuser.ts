export class Pacuser{
        id : number=0;
        firstName : string='';
        lastName : string='';
        userName: string='';
        email: string='';
        age: number=0;
        gender: string=''
        password: string='';
}