export class Vcenters{
    
        id: number= 0;
        name : string= '';
        pinCode: number=0;
}