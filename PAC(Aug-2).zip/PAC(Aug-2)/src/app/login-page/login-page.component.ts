import { Component, OnInit } from '@angular/core';
import { UrlSegment } from '@angular/router';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { AppComponent } from '../app.component';
import { PacUserService } from '../pac-user.service';
import { Pacuser } from '../pacuser';
@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.css']
})
export class LoginPageComponent implements OnInit {
  pacuser=new Pacuser();
  invalidLogin:boolean = false;
  //userName:any =""
 // password:any = ""

  constructor(private router: Router,public appComp: AppComponent, public service: PacUserService) { }

  ngOnInit(): void {
  }

  validate(typeOfLogin:any){
   // if(this.pacuser.userName!='' && this.pacuser.password!='')
    //{
      if(typeOfLogin=="user") {
this.service.loginPacuserFromRemote(this.pacuser).subscribe(
  data =>{
    console.log('response')
    this.invalidLogin = false
    this.service.setUserName(this.pacuser.userName)
    this.service.setLoggedIn(true)
   // this.router.navigate(['../adminPage']);
   //if(typeOfLogin == 'admin'){
    // if(this.pacuser.userName="aravind" && this.pacuser.password="123") {
   // this.router.navigate(['../adminPage']);
    // }
 // }
  //else{
   this.router.navigate(['../userPage']);
 // }
 // }
        },
      
        error =>{console.log("exception")
        this.invalidLogin = true
      }
)
//else{
 // this.invalidLogin = true
//}
    }
    if(typeOfLogin=="admin")
  
    {
      if(this.pacuser.userName=="vishwa" && this.pacuser.password=="tej") {
        this.service.setUserName(this.pacuser.userName)
    this.service.setLoggedIn(true)
    this.invalidLogin = false
      this.router.navigate(['../adminPage']);
      }
      else{
        this.invalidLogin = true
      }
    }
          }
   openSignUp(){
    this.router.navigate(['../signup'])
          }
}
    

 