import { Component, OnInit } from '@angular/core';
import { PacUserService } from '../pac-user.service';
import { Vcenters } from '../vcenters';

@Component({
  selector: 'app-user-homepage',
  templateUrl: './user-homepage.component.html',
  styleUrls: ['./user-homepage.component.css']
})
export class UserHomepageComponent implements OnInit {
  userTable:boolean = false;
  vCenters:boolean = false
  helpInfo:boolean = false
  showVCenter:boolean = false
  pinCode:number=0
  vcentersData:any
  vcenters:Vcenters= new Vcenters();
  constructor(public service: PacUserService) { }

  ngOnInit(): void {
  }

  onBtnClick(value:string){
    if(value == "showVCenter"){
      this.userTable = false
      this.showVCenter = true
    }
    else if(value == "userTable"){
      this.userTable = true
      this.showVCenter = false
    }
    
  }
  
   public findVcentersByPinCode(){
    let response = this.service.getVcentersByPinCode(this.pinCode);
   response.subscribe(data => this.vcentersData = data);
   }
}
