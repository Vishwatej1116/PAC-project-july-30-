package com.cts.hms.pac;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JdbcPacApplicationTests {

	@Test
	void contextLoads() {
	}

}
