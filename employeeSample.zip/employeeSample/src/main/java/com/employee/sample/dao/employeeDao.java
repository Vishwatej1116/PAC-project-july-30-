package com.employee.sample.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.employee.sample.model.employee;

@Repository
public interface employeeDao {

	
	int create(employee empl);

	List<employee> read();

	employee read(String name);
	
	List<employee> readbyId(Long id);

	int update(employee empl);

	int delete(Long id);
	
}
