package com.employee.sample.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.employee.sample.model.employee;

@Component
public class employeeDaoImpl implements employeeDao{
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Override
	public int create(employee empl) {
		return jdbcTemplate.update("INSERT INTO EMPLOYEE VALUES (?,?,?,?)", empl.getId(), empl.getName(), empl.getAddress(), empl.getDob());
	}
    
	@Override
	public List<employee> read() {
		return jdbcTemplate.query("SELECT * FROM EMPLOYEE", new employeeRowMapper());
	}
	
	@Override
	public employee read(String name) {
		return jdbcTemplate.queryForObject("SELECT * FROM EMPLOYEE WHERE name=?", new employeeRowMapper(), name);
	}
	
	@Override
	public int update(employee empl) {
		return jdbcTemplate.update("UPDATE EMPLOYEE SET name=?, address=?, dob=? WHERE id=?",empl.getName(), empl.getAddress(), empl.getDob() , empl.getId());
	}
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM EMPLOYEE WHERE id=?",id);
	}

	@Override
	public List<employee> readbyId(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
}
