package com.employee.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.sample.dao.employeeDao;
import com.employee.sample.model.employee;

@Service
public class employeeService {
	@Autowired
	private employeeDao edao;
	
	public int create(employee empl)
	{
		return edao.create(empl);
	}

	public List<employee> read()
	{
		return edao.read();
	}
	
	/*public pacUser readbyUsername(String userName)
	{
		return udao.readbyUsername(userName);
	} */

	public employee read(String name)
	{
		return edao.read(name);
	}
	
    public List<employee> readbyId(Long id) {
		
		return edao.readbyId(id);
		}

	public int update(employee empl)
	{
		return edao.update(empl);
	}

	public int delete(Long id)
	{
		return edao.delete(id);
	}
}


