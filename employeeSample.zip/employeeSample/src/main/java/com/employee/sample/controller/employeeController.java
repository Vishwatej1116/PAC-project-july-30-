package com.employee.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.sample.model.employee;
import com.employee.sample.service.employeeService;

@RestController
public class employeeController {
	@Autowired
	private employeeService es;
	
	@GetMapping("/")
	public String home()
	{
		return "Employee Data";
	}
	
	@PostMapping("/employee")
	public int addemployee(@RequestBody employee empl)
	{
		
		return es.create(empl);
	}
	
	@GetMapping("/employee")
	public List<employee> getAllemployees()
	{
		return es.read();
	}
	
	@PutMapping("/employee/{id}")
	public int modifyemployee(@RequestBody employee empl)
	{
		return es.update(empl);
	}
	
	@DeleteMapping("/employee/{id}")
	public int removeemployee(@PathVariable Long id)
	{
		return es.delete(id);
	}
}
